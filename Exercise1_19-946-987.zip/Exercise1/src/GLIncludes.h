#ifndef GL_INCLUDES_H_INCLUDED
#define GL_INCLUDES_H_INCLUDED

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#endif // GL_INCLUDES_H_INCLUDED

